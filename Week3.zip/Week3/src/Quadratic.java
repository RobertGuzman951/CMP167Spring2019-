/*
 * file : Quadratic.java
 * author:Robert Guzman
 * Created:2.14.19
 * desc : implements quardratic formula 
 */

import java.util.Scanner;
public class Quadratic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		
		double root1, root2;
		double a, b, c;
		double discr;
		
		System.out.println("Enter values for a:");
		a = input.nextDouble();
		System.out.println("Enter values for b:");
		b = input.nextDouble();
		System.out.println("Enter values for c:");
		c = input.nextDouble();
		
		discr = b*b - 4*a*c;
		root1=(-b+Math.sqrt(discr)/2 * a);
		root2=(+b+Math.sqrt(discr)/2 * a);
		
		System.out.println("root1:" + root1 + "The root 1 is"+ root2);
		
		}

}
